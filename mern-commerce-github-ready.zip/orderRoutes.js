import { Router } from 'express';
import { createOrder, myOrders } from '../controllers/orderController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = Router();

router.post('/', protect, createOrder);
router.get('/mine', protect, myOrders);

export default router;
