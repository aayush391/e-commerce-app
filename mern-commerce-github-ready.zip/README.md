# MERN Commerce

A user-friendly e-commerce starter built with MongoDB, Express, React, and Node.js.

## Features

- Customer auth with JWT
- Product catalog with search and category filtering
- Cart with quantity controls and persistent local storage
- Checkout flow with a payment-intent style endpoint
- Order creation and order history
- Admin dashboard for product and order management
- Responsive, accessible storefront UI

## Quick Start

```bash
npm run install:all
copy server\.env.example server\.env
npm run seed
npm run dev
```

The client runs on `http://localhost:5173` and the API runs on `http://localhost:5000`.

If you want a custom API URL for the frontend, copy `client/.env.example` to `client/.env`.

## Demo Accounts After Seeding

- Admin: `admin@merncommerce.dev` / `Admin123!`
- Customer: `customer@merncommerce.dev` / `Customer123!`

## Payment Integration

The backend includes a provider-shaped payment service in `server/src/services/paymentService.js`.
It returns a mock client secret by default so the checkout flow works locally without external keys.
To connect Stripe, add `STRIPE_SECRET_KEY` to `server/.env` and replace the mock branch with the Stripe SDK call shown in the comments.

## Environment

See `server/.env.example` for required server variables.
