import { PackageCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api('/orders/mine').then(setOrders).catch((err) => setError(err.message));
  }, []);

  return (
    <section className="page">
      <p className="eyebrow">Orders</p>
      <h1>Your order history</h1>
      {error && <p className="error">{error}</p>}
      {!orders.length && !error ? (
        <p className="empty-state">No orders yet.</p>
      ) : (
        <div className="order-list">
          {orders.map((order) => (
            <article className="panel order-card" key={order._id}>
              <div>
                <PackageCheck size={24} />
                <div>
                  <h3>Order #{order._id.slice(-6).toUpperCase()}</h3>
                  <p>{new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
              <span className="status">{order.orderStatus}</span>
              <strong>${order.total.toFixed(2)}</strong>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
