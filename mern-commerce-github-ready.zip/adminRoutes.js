import { Router } from 'express';
import { dashboard, listOrders, updateOrderStatus } from '../controllers/adminController.js';
import { adminOnly, protect } from '../middleware/authMiddleware.js';

const router = Router();

router.use(protect, adminOnly);
router.get('/dashboard', dashboard);
router.get('/orders', listOrders);
router.patch('/orders/:id', updateOrderStatus);

export default router;
