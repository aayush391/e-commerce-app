import { CreditCard, MapPin } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useCart } from '../state/CartContext.jsx';

export default function Checkout() {
  const { clear, items, totals } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '',
    address: '',
    city: '',
    postalCode: '',
    country: ''
  });
  const [error, setError] = useState('');
  const [placing, setPlacing] = useState(false);
  const tax = totals.subtotal * 0.08;
  const shipping = totals.subtotal > 99 ? 0 : 8.99;
  const total = Number((totals.subtotal + tax + shipping).toFixed(2));

  async function placeOrder(event) {
    event.preventDefault();
    setPlacing(true);
    setError('');
    try {
      const intent = await api('/payments/intent', {
        method: 'POST',
        body: JSON.stringify({ amount: total, currency: 'usd' })
      });
      await api('/orders', {
        method: 'POST',
        body: JSON.stringify({
          items: items.map((item) => ({ product: item._id, quantity: item.quantity })),
          shippingAddress: form,
          paymentIntentId: intent.id
        })
      });
      clear();
      navigate('/orders');
    } catch (err) {
      setError(err.message);
    } finally {
      setPlacing(false);
    }
  }

  return (
    <section className="split-page">
      <form className="panel form" onSubmit={placeOrder}>
        <p className="eyebrow">Checkout</p>
        <h1>Shipping details</h1>
        <label>
          Full name
          <input value={form.fullName} onChange={(event) => setForm({ ...form, fullName: event.target.value })} required />
        </label>
        <label>
          Address
          <input value={form.address} onChange={(event) => setForm({ ...form, address: event.target.value })} required />
        </label>
        <div className="form-row">
          <label>
            City
            <input value={form.city} onChange={(event) => setForm({ ...form, city: event.target.value })} required />
          </label>
          <label>
            Postal code
            <input
              value={form.postalCode}
              onChange={(event) => setForm({ ...form, postalCode: event.target.value })}
              required
            />
          </label>
        </div>
        <label>
          Country
          <input value={form.country} onChange={(event) => setForm({ ...form, country: event.target.value })} required />
        </label>
        {error && <p className="error">{error}</p>}
        <button className="primary" disabled={placing || !items.length} type="submit">
          <CreditCard size={18} />
          {placing ? 'Processing...' : `Pay $${total.toFixed(2)}`}
        </button>
      </form>
      <aside className="checkout-note">
        <MapPin size={28} />
        <h2>Payment ready</h2>
        <p>
          This checkout calls a payment-intent endpoint now. Add Stripe keys later without changing the customer flow.
        </p>
      </aside>
    </section>
  );
}
