import { Minus, Plus, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../state/CartContext.jsx';

export default function Cart() {
  const { items, remove, totals, update } = useCart();
  const tax = totals.subtotal * 0.08;
  const shipping = totals.subtotal > 99 || totals.subtotal === 0 ? 0 : 8.99;
  const total = totals.subtotal + tax + shipping;

  if (!items.length) {
    return (
      <section className="empty-page">
        <h1>Your cart is empty.</h1>
        <p>Add a few favorites and they will stay here until checkout.</p>
        <Link className="primary link-button" to="/">
          Start shopping
        </Link>
      </section>
    );
  }

  return (
    <section className="split-page">
      <div>
        <p className="eyebrow">Cart</p>
        <h1>Review your items</h1>
        <div className="line-items">
          {items.map((item) => (
            <article className="line-item" key={item._id}>
              <img src={item.image} alt={item.name} />
              <div>
                <h3>{item.name}</h3>
                <p>${item.price.toFixed(2)}</p>
                <div className="quantity">
                  <button onClick={() => update(item._id, item.quantity - 1)} type="button" aria-label="Decrease">
                    <Minus size={16} />
                  </button>
                  <span>{item.quantity}</span>
                  <button onClick={() => update(item._id, item.quantity + 1)} type="button" aria-label="Increase">
                    <Plus size={16} />
                  </button>
                  <button onClick={() => remove(item._id)} type="button" aria-label="Remove">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <strong>${(item.price * item.quantity).toFixed(2)}</strong>
            </article>
          ))}
        </div>
      </div>
      <aside className="panel summary">
        <h2>Order summary</h2>
        <p>
          <span>Subtotal</span>
          <strong>${totals.subtotal.toFixed(2)}</strong>
        </p>
        <p>
          <span>Tax</span>
          <strong>${tax.toFixed(2)}</strong>
        </p>
        <p>
          <span>Shipping</span>
          <strong>{shipping ? `$${shipping.toFixed(2)}` : 'Free'}</strong>
        </p>
        <p className="grand-total">
          <span>Total</span>
          <strong>${total.toFixed(2)}</strong>
        </p>
        <Link className="primary link-button" to="/checkout">
          Checkout
        </Link>
      </aside>
    </section>
  );
}
