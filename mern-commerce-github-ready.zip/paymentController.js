import { createPaymentIntent } from '../services/paymentService.js';

export async function paymentIntent(req, res, next) {
  try {
    const intent = await createPaymentIntent(req.body);
    res.status(201).json(intent);
  } catch (error) {
    next(error);
  }
}
