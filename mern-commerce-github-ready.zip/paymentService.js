export async function createPaymentIntent({ amount, currency = 'usd' }) {
  if (!amount || amount <= 0) {
    throw new Error('A valid payment amount is required');
  }

  // For Stripe:
  // const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  // return stripe.paymentIntents.create({ amount: Math.round(amount * 100), currency });
  return {
    id: `mock_pi_${Date.now()}`,
    clientSecret: `mock_secret_${Math.random().toString(36).slice(2)}`,
    amount,
    currency,
    provider: process.env.STRIPE_SECRET_KEY ? 'stripe-ready' : 'mock'
  };
}
