import { Search, SlidersHorizontal } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { api } from '../api.js';
import ProductCard from '../components/ProductCard.jsx';

const fallbackProducts = [
  {
    _id: 'demo-1',
    name: 'Everyday Tech Backpack',
    description: 'Weather-resistant backpack with a laptop pocket and quick-access storage.',
    price: 79,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80',
    stock: 42,
    rating: 4.8,
    featured: true
  },
  {
    _id: 'demo-2',
    name: 'Noise-Canceling Headphones',
    description: 'Wireless headphones with 40-hour battery life and active noise cancellation.',
    price: 149,
    category: 'Audio',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80',
    stock: 28,
    rating: 4.7,
    featured: true
  },
  {
    _id: 'demo-3',
    name: 'Performance Running Shoes',
    description: 'Lightweight knit running shoes built for daily training and city miles.',
    price: 118,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80',
    stock: 24,
    rating: 4.9,
    featured: true
  }
];

export default function Home() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/products')
      .then(setProducts)
      .catch(() => setProducts(fallbackProducts))
      .finally(() => setLoading(false));
  }, []);

  const categories = useMemo(
    () => ['All', ...new Set(products.map((product) => product.category))],
    [products]
  );

  const filtered = products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === 'All' || product.category === category;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="page">
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">Fresh picks shipped fast</p>
          <h1>Shop smarter essentials for work, home and everyday life.</h1>
          <p>
            Browse curated products, save your cart, check out securely and manage orders from a clean dashboard.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80"
          alt="Modern desk with shopping technology"
        />
      </section>

      <section className="toolbar" aria-label="Product filters">
        <label className="search-box">
          <Search size={18} />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search products" />
        </label>
        <label className="select-box">
          <SlidersHorizontal size={18} />
          <select value={category} onChange={(event) => setCategory(event.target.value)}>
            {categories.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
      </section>

      {loading ? (
        <p className="empty-state">Loading products...</p>
      ) : (
        <section className="product-grid">
          {filtered.map((product) => (
            <ProductCard key={product._id} product={product} />
          ))}
        </section>
      )}
    </div>
  );
}
