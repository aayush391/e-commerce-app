import { Plus, Star } from 'lucide-react';
import { useCart } from '../state/CartContext.jsx';

export default function ProductCard({ product }) {
  const { add } = useCart();

  return (
    <article className="product-card">
      <img src={product.image} alt={product.name} />
      <div className="product-body">
        <div>
          <p className="eyebrow">{product.category}</p>
          <h3>{product.name}</h3>
          <p>{product.description}</p>
        </div>
        <div className="product-meta">
          <span className="rating">
            <Star size={16} fill="currentColor" />
            {product.rating}
          </span>
          <span>{product.stock} in stock</span>
        </div>
        <div className="product-actions">
          <strong>${product.price.toFixed(2)}</strong>
          <button onClick={() => add(product)} type="button">
            <Plus size={18} />
            Add
          </button>
        </div>
      </div>
    </article>
  );
}
