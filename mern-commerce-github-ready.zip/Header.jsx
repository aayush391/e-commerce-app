import { LayoutDashboard, LogOut, Package, ShoppingBag, ShoppingCart, UserRound } from 'lucide-react';
import { Link, NavLink } from 'react-router-dom';
import { useAuth } from '../state/AuthContext.jsx';
import { useCart } from '../state/CartContext.jsx';

export default function Header() {
  const { user, logout } = useAuth();
  const { totals } = useCart();

  return (
    <header className="site-header">
      <Link className="brand" to="/">
        <ShoppingBag size={24} />
        MERN Commerce
      </Link>
      <nav>
        <NavLink to="/">Shop</NavLink>
        {user && <NavLink to="/orders">Orders</NavLink>}
        {user?.role === 'admin' && (
          <NavLink to="/admin">
            <LayoutDashboard size={18} />
            Admin
          </NavLink>
        )}
        <NavLink className="cart-link" to="/cart" aria-label="Cart">
          <ShoppingCart size={19} />
          <span>{totals.count}</span>
        </NavLink>
        {user ? (
          <button className="icon-text" onClick={logout} type="button">
            <LogOut size={18} />
            Sign out
          </button>
        ) : (
          <NavLink to="/auth">
            <UserRound size={18} />
            Sign in
          </NavLink>
        )}
      </nav>
    </header>
  );
}
