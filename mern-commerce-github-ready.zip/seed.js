import dotenv from 'dotenv';
import { connectDB } from './config/db.js';
import Order from './models/Order.js';
import Product from './models/Product.js';
import User from './models/User.js';

dotenv.config();

const products = [
  {
    name: 'Everyday Tech Backpack',
    description: 'Weather-resistant backpack with a laptop pocket, cable channels and quick-access storage.',
    price: 79,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80',
    stock: 42,
    rating: 4.8,
    featured: true
  },
  {
    name: 'Noise-Canceling Headphones',
    description: 'Comfortable wireless headphones with 40-hour battery life and rich active noise cancellation.',
    price: 149,
    category: 'Audio',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80',
    stock: 28,
    rating: 4.7,
    featured: true
  },
  {
    name: 'Ceramic Smart Mug',
    description: 'Keeps your drink at the perfect temperature with app-controlled presets and all-day style.',
    price: 64,
    category: 'Home',
    image: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=900&q=80',
    stock: 19,
    rating: 4.5
  },
  {
    name: 'Minimal Desk Lamp',
    description: 'Dimmable LED task lamp with warm/cool modes and a compact aluminum frame.',
    price: 54,
    category: 'Home',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80',
    stock: 31,
    rating: 4.6
  },
  {
    name: 'Performance Running Shoes',
    description: 'Lightweight knit running shoes built for city miles, gym sessions and weekend errands.',
    price: 118,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80',
    stock: 24,
    rating: 4.9,
    featured: true
  },
  {
    name: 'Portable Power Bank',
    description: 'Compact 20,000mAh fast-charging battery with USB-C PD and two-device charging.',
    price: 49,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1609592424826-4f9aef8b3c35?auto=format&fit=crop&w=900&q=80',
    stock: 56,
    rating: 4.4
  }
];

async function seed() {
  await connectDB();
  await Promise.all([User.deleteMany(), Product.deleteMany(), Order.deleteMany()]);

  await User.create([
    { name: 'Admin User', email: 'admin@merncommerce.dev', password: 'Admin123!', role: 'admin' },
    { name: 'Customer User', email: 'customer@merncommerce.dev', password: 'Customer123!', role: 'customer' }
  ]);

  await Product.insertMany(products);
  console.log('Seed data created');
  process.exit(0);
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
