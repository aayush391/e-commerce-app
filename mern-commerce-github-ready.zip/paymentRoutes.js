import { Router } from 'express';
import { paymentIntent } from '../controllers/paymentController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = Router();

router.post('/intent', protect, paymentIntent);

export default router;
