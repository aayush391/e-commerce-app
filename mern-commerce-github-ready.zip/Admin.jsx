import { DollarSign, Package, Plus, ShoppingBasket, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api } from '../api.js';

const blankProduct = {
  name: '',
  description: '',
  price: '',
  category: '',
  image: '',
  stock: '',
  rating: 4.5,
  featured: false
};

export default function Admin() {
  const [dashboard, setDashboard] = useState(null);
  const [orders, setOrders] = useState([]);
  const [product, setProduct] = useState(blankProduct);
  const [message, setMessage] = useState('');

  async function load() {
    const [dash, orderData] = await Promise.all([api('/admin/dashboard'), api('/admin/orders')]);
    setDashboard(dash);
    setOrders(orderData);
  }

  useEffect(() => {
    load().catch((err) => setMessage(err.message));
  }, []);

  async function createProduct(event) {
    event.preventDefault();
    setMessage('');
    await api('/products', {
      method: 'POST',
      body: JSON.stringify({
        ...product,
        price: Number(product.price),
        stock: Number(product.stock),
        rating: Number(product.rating)
      })
    });
    setProduct(blankProduct);
    setMessage('Product created');
    load();
  }

  async function updateStatus(orderId, orderStatus) {
    await api(`/admin/orders/${orderId}`, {
      method: 'PATCH',
      body: JSON.stringify({ orderStatus })
    });
    load();
  }

  const stats = dashboard?.stats || { orders: 0, products: 0, customers: 0, revenue: 0 };

  return (
    <section className="page">
      <p className="eyebrow">Admin dashboard</p>
      <h1>Store operations</h1>

      <div className="stats-grid">
        <Stat icon={<ShoppingBasket />} label="Orders" value={stats.orders} />
        <Stat icon={<Package />} label="Products" value={stats.products} />
        <Stat icon={<Users />} label="Customers" value={stats.customers} />
        <Stat icon={<DollarSign />} label="Revenue" value={`$${stats.revenue.toFixed(2)}`} />
      </div>

      <section className="admin-grid">
        <form className="panel form" onSubmit={createProduct}>
          <h2>Add product</h2>
          <label>
            Name
            <input value={product.name} onChange={(event) => setProduct({ ...product, name: event.target.value })} required />
          </label>
          <label>
            Description
            <textarea
              value={product.description}
              onChange={(event) => setProduct({ ...product, description: event.target.value })}
              required
            />
          </label>
          <div className="form-row">
            <label>
              Price
              <input
                type="number"
                min="0"
                value={product.price}
                onChange={(event) => setProduct({ ...product, price: event.target.value })}
                required
              />
            </label>
            <label>
              Stock
              <input
                type="number"
                min="0"
                value={product.stock}
                onChange={(event) => setProduct({ ...product, stock: event.target.value })}
                required
              />
            </label>
          </div>
          <label>
            Category
            <input value={product.category} onChange={(event) => setProduct({ ...product, category: event.target.value })} required />
          </label>
          <label>
            Image URL
            <input value={product.image} onChange={(event) => setProduct({ ...product, image: event.target.value })} required />
          </label>
          <label className="check-row">
            <input
              type="checkbox"
              checked={product.featured}
              onChange={(event) => setProduct({ ...product, featured: event.target.checked })}
            />
            Featured product
          </label>
          <button className="primary" type="submit">
            <Plus size={18} />
            Add product
          </button>
          {message && <p className="success">{message}</p>}
        </form>

        <div className="panel">
          <h2>Recent orders</h2>
          <div className="table">
            {orders.map((order) => (
              <div className="table-row" key={order._id}>
                <span>#{order._id.slice(-6).toUpperCase()}</span>
                <span>{order.user?.name || 'Customer'}</span>
                <strong>${order.total.toFixed(2)}</strong>
                <select value={order.orderStatus} onChange={(event) => updateStatus(order._id, event.target.value)}>
                  <option>processing</option>
                  <option>packed</option>
                  <option>shipped</option>
                  <option>delivered</option>
                </select>
              </div>
            ))}
          </div>
        </div>
      </section>
    </section>
  );
}

function Stat({ icon, label, value }) {
  return (
    <article className="stat">
      {icon}
      <span>{label}</span>
      <strong>{value}</strong>
    </article>
  );
}
