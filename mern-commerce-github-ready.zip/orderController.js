import Order from '../models/Order.js';
import Product from '../models/Product.js';

function money(value) {
  return Number(value.toFixed(2));
}

export async function createOrder(req, res, next) {
  try {
    const { items = [], shippingAddress, paymentIntentId } = req.body;
    if (!items.length) {
      res.status(400);
      throw new Error('Order must include at least one item');
    }

    const productIds = items.map((item) => item.product);
    const products = await Product.find({ _id: { $in: productIds } });
    const productMap = new Map(products.map((product) => [String(product._id), product]));

    const orderItems = items.map((item) => {
      const product = productMap.get(String(item.product));
      if (!product) throw new Error('Product in cart no longer exists');
      if (product.stock < item.quantity) throw new Error(`${product.name} is out of stock`);
      return {
        product: product._id,
        name: product.name,
        image: product.image,
        price: product.price,
        quantity: item.quantity
      };
    });

    const subtotal = money(orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0));
    const tax = money(subtotal * 0.08);
    const shipping = subtotal > 99 ? 0 : 8.99;
    const total = money(subtotal + tax + shipping);

    const order = await Order.create({
      user: req.user._id,
      items: orderItems,
      shippingAddress,
      subtotal,
      tax,
      shipping,
      total,
      paymentIntentId,
      paymentStatus: paymentIntentId ? 'paid' : 'pending'
    });

    await Promise.all(
      orderItems.map((item) =>
        Product.findByIdAndUpdate(item.product, { $inc: { stock: -item.quantity } })
      )
    );

    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
}

export async function myOrders(req, res, next) {
  try {
    const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    next(error);
  }
}
