import { createContext, useContext, useMemo, useState } from 'react';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useState(() => {
    const saved = localStorage.getItem('mern-commerce-cart');
    return saved ? JSON.parse(saved) : [];
  });

  function sync(next) {
    setItems(next);
    localStorage.setItem('mern-commerce-cart', JSON.stringify(next));
  }

  function add(product) {
    const existing = items.find((item) => item._id === product._id);
    const next = existing
      ? items.map((item) => (item._id === product._id ? { ...item, quantity: item.quantity + 1 } : item))
      : [...items, { ...product, quantity: 1 }];
    sync(next);
  }

  function update(id, quantity) {
    const next = items
      .map((item) => (item._id === id ? { ...item, quantity: Math.max(1, quantity) } : item))
      .filter((item) => item.quantity > 0);
    sync(next);
  }

  function remove(id) {
    sync(items.filter((item) => item._id !== id));
  }

  function clear() {
    sync([]);
  }

  const totals = items.reduce(
    (acc, item) => {
      acc.count += item.quantity;
      acc.subtotal += item.price * item.quantity;
      return acc;
    },
    { count: 0, subtotal: 0 }
  );

  const value = useMemo(() => ({ items, add, update, remove, clear, totals }), [items]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  return useContext(CartContext);
}
