import Order from '../models/Order.js';
import Product from '../models/Product.js';
import User from '../models/User.js';

export async function dashboard(req, res, next) {
  try {
    const [orders, products, customers] = await Promise.all([
      Order.find().sort({ createdAt: -1 }).limit(8).populate('user', 'name email'),
      Product.find().sort({ stock: 1 }).limit(8),
      User.countDocuments({ role: 'customer' })
    ]);

    const revenue = await Order.aggregate([
      { $match: { paymentStatus: 'paid' } },
      { $group: { _id: null, total: { $sum: '$total' } } }
    ]);

    res.json({
      stats: {
        orders: await Order.countDocuments(),
        products: await Product.countDocuments(),
        customers,
        revenue: revenue[0]?.total || 0
      },
      recentOrders: orders,
      lowStock: products
    });
  } catch (error) {
    next(error);
  }
}

export async function listOrders(_req, res, next) {
  try {
    const orders = await Order.find().sort({ createdAt: -1 }).populate('user', 'name email');
    res.json(orders);
  } catch (error) {
    next(error);
  }
}

export async function updateOrderStatus(req, res, next) {
  try {
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { orderStatus: req.body.orderStatus, paymentStatus: req.body.paymentStatus },
      { new: true, runValidators: true }
    );

    if (!order) {
      res.status(404);
      throw new Error('Order not found');
    }

    res.json(order);
  } catch (error) {
    next(error);
  }
}
